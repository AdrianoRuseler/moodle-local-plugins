## Readme

Moodle Adminer is based on the great tool adminer (www.adminer.org).
The main advantage of this plugin is, it can handle different types of database.
So it works with MySQL, PostgreSQL, Oracle and MSSQL.

Moodle Adminer is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Moodle Adminer is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You can receive a copy of the GNU General Public License
at <http:www.gnu.org/licenses/>.

### Installation:
To install Moodle Adminer just copy the folder "adminer" into your moodle/local/adminer.
After that you have to go to http://your-moodle/admin (Site administration -> Notifications) to trigger the installation process.

### Using:
To use Moodle Adminer go to "Site administration" -> "Server" -> "Moodle Adminer".
